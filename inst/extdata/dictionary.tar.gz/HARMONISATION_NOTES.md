# Harmonisation notes and decisions

This document explains when REACT fields are combined, recoded, or deliberately
kept separate. It is shared by the REACT data dictionary and `reactextract`.
The exact raw values remain available even when a cleaned value is supplied.

## General rules

- A variable is identified by its study round and exact raw name. A familiar name
  or numeric suffix is not assumed to mean the same thing in another round.
- Differences in case, punctuation, underscores, and zero-padding are preserved.
- Grouping fields under one research concept helps discovery, but does not by
  itself authorise combining their values.
- Fields are combined only after their question wording, response coding, round
  coverage, and role in the questionnaire have been reviewed.
- A cleaned output retains the source field names, raw values, decision ID, and
  transformation status. Unexpected combinations are reported rather than guessed.
- A harmonised analysis column uses the full stable concept ID, including its topic
  prefix. Constituent raw names are kept in the column dictionary rather than
  concatenated into that working name. Where several distinct fields can occur for
  one concept in the same round, component columns use the consistent form
  `concept_id__field__EXACT_RAW_FIELD`; `sub("__field__.*$", "", name)` recovers
  the concept ID.
- Database missing values remain distinct from literal text such as `NA`. Negative
  administrative codes are interpreted only where their source meaning is known
  and remain present in the raw output.

## Approved decisions

### Pre-existing health conditions

The reviewed pre-existing-condition fields use direct yes/no recoding. Raw names
changed across instruments, including forms such as `HEALTHA05`, `HEALTHA_5`, and
`HEALTHA_05`. These names are never normalised into one raw name; approved mappings
produce a common logical concept value while preserving provenance.

### Long COVID symptom duration

Approved by `mathzero` on 13 August 2026.

Later categorical duration answers are the common representation:

| Code | Cleaned response |
|---:|---|
| 1 | Less than four weeks |
| 2 | Four weeks up to two months |
| 3 | Two months up to three months |
| 4 | Three months up to six months |
| 5 | More than six months |
| 6 | Cannot give an estimate |
| 7 | Prefer not to say |

Earlier questionnaires sometimes recorded separate DAYS and WEEKS values. The
enclave check showed that these are alternative entry slots: no checked answer had
two positive values. The cleaned rule is therefore:

1. Use a positive DAYS value when present.
2. Otherwise use a positive WEEKS value multiplied by seven.
3. Treat two zeroes as zero days.
4. If two positive values ever occur, retain both raw values, leave the cleaned
   result unresolved, and add an issue record.
5. Convert the resulting days into bands at 28, 61, 92, and 183 days.

Where a later response combines several earlier symptoms—abdominal symptoms,
chest pain or tightness, runny or blocked nose, and sore throat or hoarse voice—the
longest reviewed component determines the duration band. This aggregation is
recorded in the output provenance.

REACT-1 categorical sources take their documented codes 1–7. The REACT-2 round 6
enclave fields were confirmed to use substantive codes 1–5 and administrative code
`-91`; codes 6 and 7 were not observed there and are not invented.

## Long COVID names that change meaning or number

The first 18 categorical symptom fields keep the same number between REACT-1 and
REACT-2 round 6. The following do not:

| Symptom concept | REACT-1 field | REACT-2 round 6 field |
|---|---|---|
| Difficulty sleeping | `LONGCOVIDB2_21` | `LONGCOVIDB2_22` |
| Loss of appetite | `LONGCOVIDB2_22` | `LONGCOVIDB2_23` |
| Eye irritation | `LONGCOVIDB2_25` | `LONGCOVIDB2_27` |
| Vision issues | `LONGCOVIDB2_26` | `LONGCOVIDB2_28` |
| Hearing issues | `LONGCOVIDB2_27` | `LONGCOVIDB2_29` |
| Hair loss | `LONGCOVIDB2_28` | `LONGCOVIDB2_30` |
| Sore throat or hoarse voice | `LONGCOVIDB2_29` | `LONGCOVIDB2_31` |
| Skin problems | `LONGCOVIDB2_30` | `LONGCOVIDB2_32` |
| Face or lip swelling | `LONGCOVIDB2_31` | `LONGCOVIDB2_33` |
| Foot sores or blisters | `LONGCOVIDB2_32` | `LONGCOVIDB2_34` |
| Leg swelling | `LONGCOVIDB2_36` | `LONGCOVIDB2_21` |
| Weight loss | `LONGCOVIDB2_37` | `LONGCOVIDB2_24` |
| Other symptom | `LONGCOVIDB2_99` | `LONGCOVIDB2_35` |

The earlier continuous suffixes also move between instruments. For example,
`LONGCOVIDB_2_1` is smell duration in REACT-1 round 5 but appetite duration in
later REACT-2 rounds. The software therefore uses the reviewed round-specific
occurrence contract rather than matching suffixes.

Continuous duration fields for chills, diarrhoea, limb heaviness, and nausea or
vomiting do not have a reviewed later categorical counterpart. They remain
separate source-preserving outputs.

## Decisions to keep fields separate or exclude them

- `LEAVE1` and `LEAVELOCK` have different reference periods and remain separate.
- `SELFISOEVER` and `SELFISO` refer to different people and remain separate.
- `LONGCOVID2_21` combines smell and taste whereas `LONGCOVID2_1` records smell
  alone; they remain separate.
- `DATELASTMODIFIED` and `DATEFLULASTMODIFIED` concern different laboratory
  results and remain separate.
- `EMPL2` in REACT-2 round 3 was checked against enclave data and confirmed to be
  an uninformative duplicate of `EMPL`. It is retained in source provenance but
  excluded from the main dictionary and extraction outputs.

## Proposals not yet approved

Several straightforward-looking renames, including `SMOKECIGDATE` and
`SMOKECIGDATE_NEW`, have been identified as candidates. They remain review
proposals until the exact decision set receives named approval. Candidate status
does not alter cleaned extraction.

## Where to find the exact contract

The public repository stores the reviewed groups in
`metadata/harmonisation_groups.csv` and every round-specific input in
`metadata/harmonisation_inputs.csv`. The extractor pins these files inside its
checksum-verified dictionary bundle; it does not download or update them at run
time.
