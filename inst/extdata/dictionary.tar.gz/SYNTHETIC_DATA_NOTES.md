# Synthetic REACT data: methods and limits

The synthetic-data contract lets researchers develop R code outside the REACT
enclave and run the same code against real data inside it. Synthetic output uses
the same exact raw field names and the same reviewed harmonisation pipeline as
`reactextract`; it does not contain respondent records.

## Evidence and review

The repository snapshots the 38 main REACT-1 and 12 main REACT-2 questionnaire
PDFs for the 25 in-scope rounds. The questionnaire manifest fixes their source
URLs, byte sizes, page counts and SHA-256 checksums.

Automated parsing proposed question-to-field links and routing rules. `mathzero`
approved the corrected version-1 routing sets for both studies on 2026-08-17:
1,989 rules covering 27,499 exact parent-to-child links. Every approved rule
retains its questionnaire and page locator. The exact reviewed files and rule IDs
are checksum-locked, so a later parser change cannot silently inherit that
approval.

### Eligibility termination fields

Routing involving `EXCL` or `EXCLCONF` is deliberately excluded. A value of 1
on either field sends the respondent to the close/end-survey branch, so no
analysable downstream questionnaire row is available to reproduce. The decision
was confirmed during human review on 2026-08-14. Removed machine candidates are
retained in the review artifact's `routing-excluded-eligibility.csv` audit file.

The same review identified a parser-boundary hazard: a termination instruction
could previously be joined to the next raw-field anchor. Routing extraction now
stops at `CLOSE`, `END SURVEY`, other explicit termination markers, or a new `IF`
statement. Regression tests prohibit eligibility fields and termination-crossing
evidence from entering candidate or approved routing metadata.

Inline `[IF ...]` fragments embedded in question wording are display substitutions,
not administration gates. For example, they may select “the person” versus “the
last person” when describing a previous contact. They must not create dependencies
on later questionnaire fields. Candidate evidence is therefore required to begin
with an explicit routing instruction (`IF`, `ASK IF`, `ASK field=...`, or a
standalone field condition); other fragments are retained only in the rejected
display-text audit.

### Downstream field anchors

The 2026-08-17 review found that an earlier parser could mistake a capitalised word
at the start of ordinary question text for a raw-field name. This produced false
links such as `NADULTS1` to participant `AGE`, `SWASTATUSNO` to `DOB`, `CAREHOME`
to `CTRYBORN`, work-type fields to `ETHNIC`, and `LONGCOVID1` to age fields.

Downstream targets are now accepted only when an exact raw code is shown as a
standalone questionnaire anchor immediately before or after the routing instruction,
or when PDF text extraction has visibly joined the raw code to the condition. Search
stops as soon as ordinary question prose begins. Wording-only conditions such as
“IF `SWASTATUSNO` = 3: Why do you think…” and “IF `LONGCOVID1` = 1: Thinking
about…” are recorded as display logic rather than administration gates.

The corrected repeated-round relationships are:

- `NADULTS1` controls the repeated `ADULTAGE1` fields; it does not control the
  respondent's `AGE`.
- `SWASTATUSNO` values 2 or 3 control `SWAWHYN2`; they do not control `DOB`.
- `CAREHOME` values 2 or 3 control `PERSCARE`; they do not control `CTRYBORN`.
- selected `WORKTYP1` options 5, 6 or 7 control `WORKTYP2`; from Round 8 onward,
  the equivalent household rule links `WORKTYP3` options 5, 6 or 7 to `WORKTYP4`.
  Neither relationship controls `ETHNIC`, and unrelated raw fields such as `SCHOOL`
  are not part of the condition.
- `LONGCOVID1` controls the named Long COVID symptom, duration, impact and care
  fields shown in each instrument; it does not control age or household fields.

These corrections are part of the approved version-1 routing contract.

## Profiling dispositions

Routing approval does not permit the extractor to inspect every field in the same
way. A separate safety review assigns one treatment to every included occurrence:

- published response codes are counted as categories;
- uncoded checkbox fields use exact 0/1 support;
- numbers and dates are counted only in fixed public ranges;
- free text contributes only a present/absent count and is replaced by the fixed
  phrase `Synthetic response`;
- names, postcodes and filenames are excluded;
- respondent and prior-REACT IDs are never profiled and are generated afresh.

`mathzero` approved all 15,093 dispositions and the 15 fixed-range
specifications on 2026-08-17. The exact proposal files and occurrence-ID set are
checksum-locked. This approval is separate from disclosure approval of the
eventual enclave aggregate profile.

## Aggregate profile boundary

Real distributions are calculated only inside the enclave. The export contains
rounded, disclosure-controlled aggregate counts; it never contains respondent
identifiers, raw free text, row examples, exact extrema or data-derived bin
boundaries. Counts below 10 receive primary and complementary suppression and
released counts are rounded to the nearest 5. Automated checks do not constitute
disclosure approval.

`reactextract` 0.3.0 uses the checksum-fixed
`react-synthetic-profile-v2-sanitised` profile by default. Its public-domain
development fallback remains available only by explicit request.

### Targeted categorical correction

The distribution audit found 168 round-specific fields whose local source rows
did not contain their category labels even though the same study, exact raw name
and exact question label have one unambiguous public response definition in
other rounds. They were consequently profiled as generic numbers. The affected
set includes `AGE_GROUP` in REACT-1 Round 3 and REACT-2 Rounds 1 and 2.

Dictionary release rc9 treats those 168 fields as categories and records the
supporting occurrence for every correction. Genuine counts and measurements
are excluded. `reactextract` 0.3.1 is an enclave repair build that queries only
these fields and retains all unaffected aggregates and routing results. Its
output still requires normal disclosure approval before it can replace the
profile used by the public synthetic generator.

### Administrative missing codes

The profiling and generation contract treats the documented negative values
`-91`, `-92`, `-77`, `-66`, `-99` and `-555` as administrative missing states,
not as ordinary negative measurements. This rule applies even when an early
round's source catalogue omits the corresponding response label. Their literal
values remain available in raw and synthetic data, separately from database
missing values.

### Occurrence-specific laboratory labels

Laboratory result text is case-sensitive and is never trimmed or normalised.
Most REACT-1 `RESULT` and `FINALRESULT` fields use the shared exact support
`Detected`, `Not Detected`, `Void` and a single space. A disclosure-controlled
aggregate diagnostic identified three additional ASCII labels with narrower
scope:

- REACT-1 Round 2 `FINALRESULT`: `Rejected`, treated as missing;
- REACT-1 Round 11 `RESULT`: `negative`, treated as negative;
- REACT-1 Round 13 `RESULT`: `ambiguous`, treated as missing.

Each field has its own support identifier. These labels are not valid for any
other occurrence. The public-support table records an `outcome_state` for every
exact label: `detected` means the reviewed round-specific Ct rule must still be
applied, while `negative` and `missing` are final states. An unknown
laboratory-result label never defaults to a negative test.

Round 2 PCR positivity is derived from exact `RESULT`, `CT_VALUE1` and
`CT_VALUE2` values. `FINALRESULT` is not an outcome input for that round, so its
occurrence-specific `Rejected` value remains visible as missing evidence but
cannot change the derived PCR result. Likewise, exact lowercase `negative` is a
negative result only for Round 11 `RESULT`, while exact lowercase `ambiguous` is
missing only for Round 13 `RESULT`. `Void`, blank and any other unknown
laboratory-result label fail closed to missing rather than falling through to a
negative result.

Round-specific counts and all-round counts are disclosure-controlled
separately. An all-round count must be calculated from the unsuppressed round
aggregates inside the enclave. It must never be reconstructed by adding public
round tables after suppressed cells have been removed.

The approved sanitised release contains round-specific distributions but records
`overall_distributions = not_available_after_targeted_repair`. The wiki therefore
shows only the approved round-specific counts. An all-round display remains
deferred until separately calculated and approved aggregate totals are available.

## Generation behaviour

- Participants and identifiers are fictional and independent in each round.
- Questionnaire routing is applied only from approved rules.
- Database missingness remains distinct from literal strings and documented
  negative administrative codes.
- Free text uses the fixed value `Synthetic response`; sensitive text is omitted.
- Suppressed public response states receive a one-percent uniform safety prior.
- Missing profile support produces a recorded fallback or a missing value, never
  an estimate inferred from hidden counts.

Synthetic data are unsuitable for prevalence estimates, hypothesis testing,
power calculations or substantive scientific conclusions.
