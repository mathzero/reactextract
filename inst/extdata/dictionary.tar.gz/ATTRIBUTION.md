# REACT dictionary bundle attribution

Dictionary release: `v1.0.0-rc9`

The metadata in this bundle is licensed under CC BY 4.0.
Attribution: REACT metadata wiki contributors.

This bundle contains metadata only. It contains no respondent data.
Only approved mappings and transforms may drive harmonised extraction.
