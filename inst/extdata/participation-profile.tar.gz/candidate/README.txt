Compact participation candidate: normal enclave disclosure approval required.
Only saved aggregate counts were used. No database queries or respondent records.
Not a generator-ready v6 profile. Do not install or publish this folder as a profile.
See AVAILABILITY.md and availability.csv before requesting release review.
Keep the original INTERNAL checkpoint and this script's R workspace inside the enclave.
