# Availability of the protected compact export

Core distributions with usable counts: **44 of 50**.

These are counts of exported distributions, not counts of people. Hidden entries are unknown, not zero.

- Participation is usable only when both binary state counts are visible.
- NHS age is usable for a partial profile when at least two public age-bin counts are visible. Hidden bins still require an explicitly documented public prior; this is not complete distribution recovery.
- Other field profiles can remain partly or wholly unavailable. availability.csv lists them without revealing hidden counts.

## Action

Some required distributions are unavailable. Return this protected report with the candidate for review; do not repeat the database pull or fill hidden cells with zeros.

Technical checks do not grant disclosure approval. Generator integration, remaining questionnaire rules and profile approval are still required.

## Required distributions needing attention

- react2.r01 / shared_participation: unavailable
- react2.r02 / shared_participation: unavailable
- react2.r03 / shared_participation: unavailable
- react2.r04 / shared_participation: unavailable
- react2.r05 / shared_participation: unavailable
- react2.r06 / shared_participation: unavailable
